function Enviar() {
    var nome = document.getElementById("nomeid");

    if (nome.value != "") {
    }
}

function limpa_formulário_cep() {
    //limpa o bagre

    document.getElementById("ruaid").value = ("");
    document.getElementById("bairroid").value = ("");
    document.getElementById("cidadeid").value = ("");
    document.getElementById("ufid").value = ("");
}
function meu_callback(conteudo) {
    if (!("erro" in conteudo)) {
        document.getElementById("ruaid").value = (conteudo.logradouro);
        document.getElementById("bairroid").value = (conteudo.bairro);
        document.getElementById("cidadeid").value = (conteudo.localidade);
        document.getElementById("ufid").value = (conteudo.uf);
    
    } else {
        limpa_formulário_cep();
        alert("se errou mano, arruma ai")

    }

}
function pesquisacep(valor) {
    var cep = valor.replace(/\D/g, '');

    if (cep != "") {

        var validacep = /^[0-9]{8}$/;

        if (validacep.test(cep)) {

            document.getElementById("ruaid").value = "..."
            document.getElementById("bairroid").value = "..."
            document.getElementById("cidadeid").value = "..."
            document.getElementById("ufid").value = "..."

            var script = document.createElement("script");

            script.src = "https://viacep.com.br/ws/" + cep + "/json/?callback=meu_callback";

            document.body.appendChild(script);
        } else {
            limpa_formulário_cep();
            alert("acerta essa merda fdp")


        }

    }
}

 function pesquisacep(valor) {
    var cep=valor.replace (/\D/g, '');
    if (cep != "") {
        var validacep = /^[0-9]{8}$/;
        if (validacep.test(cep)){
            document.getElementById("ruaid").value = "..."
            document.getElementById("bairroid").value = "..."
            document.getElementById("cidadeid").value = "..."
            document.getElementById("ufid").value = "..."
             var script= document;createElement('script');

             script.src='https://viacep.com.br/ws/' + cep + '/json/?callback=meu_callback'
             document.body.appendChild(script);
        } else {
            limpa_formulário_cep();
            alert ('nao aguento mais')

        }

 } else{ 
    limpa_formulário_cep();
 }
}